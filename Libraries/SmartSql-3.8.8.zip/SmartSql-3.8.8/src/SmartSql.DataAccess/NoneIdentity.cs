﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SmartSql.DataAccess
{
    /// <summary>
    /// 无自增主键返回
    /// </summary>
    public class NoneIdentity
    {
    }
}
