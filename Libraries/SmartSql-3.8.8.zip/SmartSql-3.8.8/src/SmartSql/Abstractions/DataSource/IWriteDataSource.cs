﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SmartSql.Abstractions.DataSource
{
    /// <summary>
    /// 数据源- 写库
    /// </summary>
    public interface IWriteDataSource : IDataSource
    {
    }
}
