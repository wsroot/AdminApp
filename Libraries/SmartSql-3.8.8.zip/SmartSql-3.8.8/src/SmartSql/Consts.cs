﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SmartSql
{
    public class Consts
    {
        public const string DEFAULT_SMARTSQL_CONFIG_PATH = "SmartSqlMapConfig.xml";
    }
}
