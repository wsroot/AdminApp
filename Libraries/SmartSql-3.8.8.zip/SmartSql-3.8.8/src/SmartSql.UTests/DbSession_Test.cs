﻿using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace SmartSql.UTests
{
    public class DbSession_Test
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
