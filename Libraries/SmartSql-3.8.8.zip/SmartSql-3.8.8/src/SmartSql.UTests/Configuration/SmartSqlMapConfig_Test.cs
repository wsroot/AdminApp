﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SmartSql.UTests.Configuration
{
    public class SmartSqlMapConfig_Test
    {

    }
}
