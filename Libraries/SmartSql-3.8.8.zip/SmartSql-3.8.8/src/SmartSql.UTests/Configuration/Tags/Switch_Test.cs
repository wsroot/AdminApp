﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SmartSql.UTests.Configuration.Tags
{
    public class Switch_Test
    {

    }
}
