﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SmartSql.UTests.Configuration.Statements
{
    class Statement_Test
    {
    }
}
