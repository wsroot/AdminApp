﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SmartSql.UTests.Cache
{
    public class FifoCacheProvider_Test
    {
    }
}
