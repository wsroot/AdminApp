﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SmartSql.ZooKeeperConfig
{
    public class AuthInfo
    {
        public string Scheme { get; set; }
        public byte[] Data { get; set; }
    }
}
